<?php

include ('conn.php');
 
 
if (isset($_POST['submit'])) { 
    $user = $_POST['uname'];
    $pass = $_POST['upass'];
 
    $stmt = $conn->prepare("SELECT  fname,profile_pic,Status,isAdmin,id,upass FROM user_tbl WHERE uname = ?");
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Bind result variables
        $stmt->bind_result($fname,$profile_pic,$Status,$isAdmin,$userID,$hashed_password);
        $stmt->fetch();
 
        if (password_verify($pass, $hashed_password)) {  
            session_start(); 
            
            $_SESSION["IsLogin"]="1";  
            $_SESSION["pass"]=$_POST['upass'];
            $_SESSION["UserID"]=$userID;
            $_SESSION["sys_color"]="#709EBD";  
            $_SESSION["profile_pic"]=$profile_pic;
            $_SESSION["fname"]=$fname;
            $_SESSION["num"]=0;

            if ($Status==1){
              echo "Sorry, this access is already INACTEVATED!"; 
              return;
            }

            if ($isAdmin==1){
              header("Location: admin"); 
              return;
            }

            header("Location: pages"); 
            
        } else {
            echo "Invalid password!";
        }
    } else {
        echo "No user found with that username!";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>

<html>
  <head>
  <?php  include('web_thems.php'); ?> 

  </head>
  <style></style>
  <body></body>
  <form method="POST">
    <div class="container">
      
    <a href="register.php">Register now</a>
    <br><br>

    <div class="row">
      <div class="col-md-4">
        Username:
        <input type="text" name="uname" class="form-control"/>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4">
        Username:
        <input type="password" name="upass" class="form-control"/>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4">
        <br>
        <button class="btn btn-info" name="submit">Login</button>
      </div>
    </div>
    </div>

  </form>
</html>