<?php

$servername = "localhost";
$username = "root"; // replace with your database username
$password = ""; // replace with your database password
$dbname = "comm_box_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

?>