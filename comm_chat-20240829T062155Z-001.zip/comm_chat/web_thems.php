<head> 

<link rel="stylesheet" href="bootstrap/css/bootstrap.css"/>
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"/>
<link rel="stylesheet" href="bootstrap/css/bootstrap-grid.css"/>
<link rel="stylesheet" href="bootstrap/css/bootstrap-grid.min.css"/>
<link rel="stylesheet" href="bootstrap/css/bootstrap-reboot.css"/>
<link rel="stylesheet" href="bootstrap/css/bootstrap-reboot.min.css"/>

<link rel="stylesheet" href="bootstrap/css/bootstrap_341.min.css"/>
<link rel="stylesheet" href="bootstrap/css/font_lato.css"/>
<link rel="stylesheet" href="bootstrap/css/font_Montserrat.css"/>
<link rel="stylesheet" href="bootstrap/css/awesome.css"/>

 
<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="bootstrap/js/bootstrap.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script> 
<script src="bootstrap/js/jquery.min.js"></script> 

</head>
